package hello.core.member;

public enum Grade { //회원 등급 설정을 위한 ENUM CLASS(상수 클래스. 변동의 여지가 없기 때문)
    BASIC,
    VIP
}
